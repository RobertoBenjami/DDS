/*
 * fmgen.h
 *
 *  Created on: 2019. m�rc. 15.
 *      Author: Benjami
 */

#ifndef __FMGEN_H_
#define __FMGEN_H_

void FmGen(void);
void FmStereoGen(void);

#endif /* __FMGEN_H_ */
