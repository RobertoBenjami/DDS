/*
 * sweepgen.h
 *
 *  Created on: 2019. m�rc. 19.
 *      Author: Benjami
 */

#ifndef SWEEPGEN_H_
#define SWEEPGEN_H_

void SweepGen(void);

#endif /* SWEEPGEN_H_ */
