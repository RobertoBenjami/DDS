#include <stdlib.h>
#include <string.h>
#include "main.h"
#include "ddsmain.h"
#include "control.h"
#include "fgen.h"
#include "fmgen.h"
#include "fmmod.h"
#include "sweepgen.h"
#include "stm32_adafruit_lcd.h"
#include "cmsis_os.h"
#include "ddsdrv.h"

//============================================================================
// 16bites szin el��llit�sa RGB (ill. BGR) �sszetev�kb�l
#define RGB888TORGB565(r, g, b)  ((r & 0b11111000) << 8 | (g & 0b11111100) << 3 | b >> 3)
#define RGB888TOBGR565(r, g, b)  (r >> 3 | (g & 0b11111100) << 3 | (b & 0b11111000) << 8)

const RASTER Rasters[RASTERNUM] =
{
  {1, "0.1Hz"},
  {10, "1Hz"},
  {50, "5Hz"},
  {100, "10Hz"},
  {250, "25Hz"},
  {500, "50Hz"},
  {1000,"100Hz"},
  {2500,"250Hz"},
  {5000,"500Hz"},
  {10000, "1kHz"},
  {25000, "2.5kHz"},
  {50000, "5kHz"},
  {100000, "10kHz"},
  {250000, "25kHz"},
  {500000, "50kHz"},
  {1000000, "100kHz"},
  {2500000, "250kHz"},
  {5000000, "500kHz"},
  {10000000, "1MHz"}
};

#define MAINMENUSIZE    5
const MENUITEM MainMenu[MAINMENUSIZE] =
{ // x, y, norm.colors, selected.colors, function, text
  {0, 10, DDS_DEFTEXTCL_1, DDS_DEFBACKCL_1, DDS_DEFTEXTCL_2, DDS_DEFBACKCL_2, DDS_DEFTEXTCL_3, DDS_DEFBACKCL_3, FGen, "Frequency generator"},
  {0, 30, DDS_DEFTEXTCL_1, DDS_DEFBACKCL_1, DDS_DEFTEXTCL_2, DDS_DEFBACKCL_2, DDS_DEFTEXTCL_3, DDS_DEFBACKCL_3, SweepGen, "Sweep generator"},
  {0, 50, DDS_DEFTEXTCL_1, DDS_DEFBACKCL_1, DDS_DEFTEXTCL_2, DDS_DEFBACKCL_2, DDS_DEFTEXTCL_3, DDS_DEFBACKCL_3, FmGen, "FM generator"},
  {0, 70, DDS_DEFTEXTCL_1, DDS_DEFBACKCL_1, DDS_DEFTEXTCL_2, DDS_DEFBACKCL_2, DDS_DEFTEXTCL_3, DDS_DEFBACKCL_3, FmStereoGen, "FM stereo generator"},
  {0, 90, DDS_DEFTEXTCL_1, DDS_DEFBACKCL_1, DDS_DEFTEXTCL_2, DDS_DEFBACKCL_2, DDS_DEFTEXTCL_3, DDS_DEFBACKCL_3, FmMod, "FM modulator"}
};

// 1024 elem� 16bites sinus t�bl�zat els� negyede (a t�bbi ebb�l a t�bl�zatbol kiolvashato a getsine1024 makroval)
const int16_t sine1024q[] = {
       0,   201,   402,   603,   804,  1005,  1206,  1407,  1608,  1809,  2009,  2210,  2410,  2611,  2811,  3012,
    3212,  3412,  3612,  3811,  4011,  4210,  4410,  4609,  4808,  5007,  5205,  5404,  5602,  5800,  5998,  6195,
    6393,  6590,  6786,  6983,  7179,  7375,  7571,  7767,  7962,  8157,  8351,  8545,  8739,  8933,  9126,  9319,
    9512,  9704,  9896, 10087, 10278, 10469, 10659, 10849, 11039, 11228, 11417, 11605, 11793, 11980, 12167, 12353,
   12539, 12725, 12910, 13094, 13279, 13462, 13645, 13828, 14010, 14191, 14372, 14553, 14732, 14912, 15090, 15269,
   15446, 15623, 15800, 15976, 16151, 16325, 16499, 16673, 16846, 17018, 17189, 17360, 17530, 17700, 17869, 18037,
   18204, 18371, 18537, 18703, 18868, 19032, 19195, 19357, 19519, 19680, 19841, 20000, 20159, 20317, 20475, 20631,
   20787, 20942, 21096, 21250, 21403, 21554, 21705, 21856, 22005, 22154, 22301, 22448, 22594, 22739, 22884, 23027,
   23170, 23311, 23452, 23592, 23731, 23870, 24007, 24143, 24279, 24413, 24547, 24680, 24811, 24942, 25072, 25201,
   25329, 25456, 25582, 25708, 25832, 25955, 26077, 26198, 26319, 26438, 26556, 26674, 26790, 26905, 27019, 27133,
   27245, 27356, 27466, 27575, 27683, 27790, 27896, 28001, 28105, 28208, 28310, 28411, 28510, 28609, 28706, 28803,
   28898, 28992, 29085, 29177, 29268, 29358, 29447, 29534, 29621, 29706, 29791, 29874, 29956, 30037, 30117, 30195,
   30273, 30349, 30424, 30498, 30571, 30643, 30714, 30783, 30852, 30919, 30985, 31050, 31113, 31176, 31237, 31297,
   31356, 31414, 31470, 31526, 31580, 31633, 31685, 31736, 31785, 31833, 31880, 31926, 31971, 32014, 32057, 32098,
   32137, 32176, 32213, 32250, 32285, 32318, 32351, 32382, 32412, 32441, 32469, 32495, 32521, 32545, 32567, 32589,
   32609, 32628, 32646, 32663, 32678, 32692, 32705, 32717, 32728, 32737, 32745, 32752, 32757, 32761, 32765, 32766,
   32767
};

// Program �llapota
uint32_t  Status = STATUS_STOP;

// temp string
uint8_t   s[128];              // �tmeneti string sprintf haszn�lathoz

//-----------------------------------------------------------------------------
void LcdMainMenu(int16_t mselect)
{
  for(int16_t i = 0; i < MAINMENUSIZE; i++)
  {
    if(i == mselect)
    {
      BSP_LCD_SetTextColor(MainMenu[i].SelectTextColor);
      BSP_LCD_SetBackColor(MainMenu[i].SelectBackColor);
    }
    else
    {
      BSP_LCD_SetTextColor(MainMenu[i].TextColor);
      BSP_LCD_SetBackColor(MainMenu[i].BackColor);
    }
    BSP_LCD_DisplayStringAt(MainMenu[i].x, MainMenu[i].y, (uint8_t *)MainMenu[i].Menutext, CENTER_MODE);
  }
}

//-----------------------------------------------------------------------------
void StartDefaultTask(void const * argument)
{
  osEvent   ctrlevent;
  control_t ctrlmsg;
  int16_t   menuselect = 0;

  BSP_LCD_Init();
  BSP_LCD_Clear(LCD_COLOR_BLACK);
  BSP_LCD_SetBackColor(LCD_COLOR_BLACK);
  BSP_LCD_SetTextColor(LCD_COLOR_YELLOW);

  osDelay(50);

  LcdMainMenu(menuselect);
  while(1)
  {
    ctrlevent = osMessageGet(controlQueueHandle, osWaitForever);
    ctrlmsg.Data = ctrlevent.value.v;

    if(ctrlmsg.Control == ENCODER_ROTATE)
    {
      menuselect+= ctrlmsg.Value;
      if(menuselect < 0)
        menuselect = 0;
      else if(menuselect >= MAINMENUSIZE)
        menuselect = MAINMENUSIZE - 1;
      LcdMainMenu(menuselect);
    }

    else if(ctrlmsg.Control == ENCODER_BTN_DOUBLECLICK)
    {
      MainMenu[menuselect].fp();
      BSP_LCD_Clear(LCD_COLOR_BLACK);
      LcdMainMenu(menuselect);
    }
  }
}
