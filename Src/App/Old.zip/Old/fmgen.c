/*
 * fmgen.c
 *
 *  Created on: 2019. m�rc. 15.
 *      Author: Benjami
 */

#include <stdlib.h>
#include <string.h>
#include "main.h"
#include "ddsmain.h"
#include "ddsdrv.h"
#include "control.h"
#include "stm32_adafruit_lcd.h"

#define FMGENMENUSIZE    8
const MENUITEM FmGenMenu[FMGENMENUSIZE] =
{
  {0, 10, DDS_DEFCOLORS, 0, "FM Gen Stop"},
  {0, 10, DDS_DEFCOLORS, 0, "FM Gen Run"},
  {0, 30, DDS_DEFCOLORS, 0, "Freq:"},
  {0, 44, DDS_DEFCOLORS, 0, "Raster:"},
  {0, 70, DDS_DEFCOLORS, 0, "Mod Freq:"},
  {0, 90, DDS_DEFCOLORS, 0, "Mod Depht:"},
  {0,110, DDS_DEFCOLORS, 0, "Encoder: menuselect"},
  {0,110, DDS_DEFCOLORS, 0, " Encoder: setting  "}
};

#define FMSTEREOGENMENUSIZE    8
const MENUITEM FmStereoGenMenu[FMSTEREOGENMENUSIZE] =
{
  {0, 10, DDS_DEFCOLORS, 0, "FM Gen Stop"},
  {0, 10, DDS_DEFCOLORS, 0, "FM Gen Run"},
  {0, 30, DDS_DEFCOLORS, 0, "Freq:"},
  {0, 44, DDS_DEFCOLORS, 0, "Raster:"},
  {0, 70, DDS_DEFCOLORS, 0, "Mod Freq:"},
  {0, 90, DDS_DEFCOLORS, 0, "Mod Depht:"},
  {0,110, DDS_DEFCOLORS, 0, "Encoder: menuselect"},
  {0,110, DDS_DEFCOLORS, 0, " Encoder: setting  "}
};


volatile uint32_t  ddsFmTime = 0;

struct TFM
{
  int32_t fgFreq_dhz;   // tized Hz-ben be�ll�tott frekvencia (pl. 1kHz -> 10000)
  int32_t fgRaster;     // 0 = tized Hz, 1 = 1Hz ... 18 = 1MHz
  int32_t fmFreq;       // modul�lo jel frekvenci�ja
  int32_t fmDepth_dhz;  // modul�cios m�lys�g (tized Hz)
  int32_t tstep;        // t�bl�zat felt�lt�s�hez sinus t�bla l�p�sk�z
  int32_t fsample;      // frekvencia frissit�s mintav�teli frekvenci�ja
  int32_t resample;     // 0: a t�bl�zat egyik fele sincs aktualiz�lva,
                        // 1: a t�bl�zat els� fele aktu�lis �rt�ket tartalmaz
                        // 2: a t�bl�zat m�sodik fele aktu�lis �rt�ket tartalmaz
                        // 3: a t�bl�zat teljesen aktu�lis �rt�ket tartalmaz
}tfm = {10000, 9, 1000, 0, 1, 96000, 3};

struct TFMST
{
  int32_t fgFreq_dhz;   // tized Hz-ben be�ll�tott frekvencia (pl. 1kHz -> 10000)
  int32_t fgRaster;     // 0 = tized Hz, 1 = 1Hz ... 18 = 1MHz
  int32_t fmFreq;       // modul�lo jel frekvenci�ja (Hz)
  int32_t fmStBallance; // modul�lo jel csatorna eloszl�sa (-255=csak bal, 0=k�z�p, 256=csak jobb csatorna
  int32_t fmPilotLevel; // a 19kHz-es pilot jel amplitudoja (0..255)
  int32_t fmDepth_dhz;  // modul�cios m�lys�g (tized Hz)
  int32_t tstep;        // t�bl�zat felt�lt�s�hez sinus t�bla l�p�sk�z
  int32_t fsample;      // frekvencia frissit�s mintav�teli frekvenci�ja
  int32_t resample;     // 0: a t�bl�zat egyik fele sincs aktualiz�lva,
                        // 1: a t�bl�zat els� fele aktu�lis �rt�ket tartalmaz
                        // 2: a t�bl�zat m�sodik fele aktu�lis �rt�ket tartalmaz
                        // 3: a t�bl�zat teljesen aktu�lis �rt�ket tartalmaz
}tfmst = {10000000, 14, 1000, 0, 8192, 500000, 1, 76000, 3};

// Pilotjel el��llit�s�hoz ennyit kell ugrani a sinust�bl�zatban
#define FMST_PILOTSTEP  256

//-----------------------------------------------------------------------------
void LcdFmColor(int16_t mselectonoff, int16_t i)
{
  if(!mselectonoff)
  {
    BSP_LCD_SetTextColor(FmGenMenu[i].TextColor);
    BSP_LCD_SetBackColor(FmGenMenu[i].BackColor);
  }
  else if(mselectonoff == 1)
  {
    BSP_LCD_SetTextColor(FmGenMenu[i].SelectTextColor);
    BSP_LCD_SetBackColor(FmGenMenu[i].SelectBackColor);
  }
  else
  {
    BSP_LCD_SetTextColor(FmGenMenu[i].ModifyTextColor);
    BSP_LCD_SetBackColor(FmGenMenu[i].ModifyBackColor);
  }
}

//-----------------------------------------------------------------------------
/* LCD <- DDS FM parameters
   Input:
   - tfm variable
   - mselect: wich menu item is selected (0 .. FMSTEREOGENMENUSIZE-1)
   - runstop: run / stop status
   - em: encoder mode (0: menu select mode, 1: menu item modify mode)
*/
void LcdFmGen(int16_t mselect, int16_t runstop, int16_t em)
{
  /* mselect, menuitem_number, em, i */
  #define COLORSELECT(a, b, c, d)    {if(a == b) {if(c) d = 2; else d = 1; } else d = 0;}
  uint32_t a;
  int16_t i;

  // �zemmod
  if(runstop)
    i = 1;
  else
    i = 0;
  LcdFmColor(mselect == 0, i);
  BSP_LCD_DisplayStringAt(FmGenMenu[i].x, FmGenMenu[i].y, (uint8_t *)FmGenMenu[i].Menutext, CENTER_MODE);

  // Frekvencia
  COLORSELECT(mselect, 1, em, i);
  LcdFmColor(i, 2);
  sprintf((char *)&s, " %s%d ", (char *)FmGenMenu[2].Menutext, (int)tfm.fgFreq_dhz);
  a = strlen((char *)s);
  s[a - 4] = s[a - 5]; s[a - 5] = '.';
  BSP_LCD_DisplayStringAt(FmGenMenu[2].x, FmGenMenu[2].y, (uint8_t *)s, CENTER_MODE);

  // Raster
  COLORSELECT(mselect, 1, em, i);
  LcdFmColor(i, 3);
  sprintf((char *)&s, " %s%s ", FmGenMenu[3].Menutext, Rasters[tfm.fgRaster].fRasterText);
  BSP_LCD_DisplayStringAt(FmGenMenu[3].x, FmGenMenu[3].y, (uint8_t *)s, CENTER_MODE);

  // Modul�cios frekvencia
  COLORSELECT(mselect, 2, em, i);
  LcdFmColor(i, 4);
  sprintf((char *)&s, " %s%d ", FmGenMenu[4].Menutext, (int)tfm.fmFreq);
  BSP_LCD_DisplayStringAt(FmGenMenu[4].x, FmGenMenu[4].y, (uint8_t *)s, CENTER_MODE);

  // Modul�cios m�lys�g
  COLORSELECT(mselect, 3, em, i);
  LcdFmColor(i, 5);
  sprintf((char *)&s, " %s%d ", FmGenMenu[5].Menutext, (int)tfm.fmDepth_dhz);
  BSP_LCD_DisplayStringAt(FmGenMenu[5].x, FmGenMenu[5].y, (uint8_t *)s, CENTER_MODE);

  // Encoder
  if(em == 0)
    i = 6;
  else
    i = 7;
  LcdFmColor(0, i);
  BSP_LCD_DisplayStringAt(FmGenMenu[i].x, FmGenMenu[i].y, (uint8_t *)FmGenMenu[i].Menutext, CENTER_MODE);
}

//-----------------------------------------------------------------------------
void FmCallback(uint32_t u)
{
  uint32_t i, sp, stp;
  int32_t  si;

  ddsFmTime++;

  if(tfm.resample == 3)
    return;

  stp = tfm.tstep;
  if(u == 0)
  { // buffer 1.fele irhato
    if((tfm.resample & 1) == 0)
    {
      sp = 0;
      for(i = 0; i < (DDS_SAMPLESIZE >> 1); i++)
      {
        getsine1024(si, sp);            // si = sinus[sp]
        ddsSamples[i] = FreqDHzToDds(tfm.fgFreq_dhz + ((int64_t)tfm.fmDepth_dhz * si) / 32767);
        sp += stp;
        if(sp >= DDS_SAMPLESIZE)
          sp -= DDS_SAMPLESIZE;
      }
      tfm.resample |= 1;
    }
  }
  else
  { // buffer 2.fele irhato
    if((tfm.resample & 2) == 0)
    {
      sp = ((DDS_SAMPLESIZE >> 1) * tfm.tstep) & (DDS_SAMPLESIZE - 1);
      for(i = DDS_SAMPLESIZE >> 1; i < DDS_SAMPLESIZE; i++)
      {
        getsine1024(si, sp);            // si = sinus[sp]
        ddsSamples[i] = FreqDHzToDds(tfm.fgFreq_dhz + ((int64_t)tfm.fmDepth_dhz * si) / 32767);
        sp += stp;
        if(sp >= DDS_SAMPLESIZE)
          sp -= DDS_SAMPLESIZE;
      }
      tfm.resample |= 2;
    }
  }
}

//-----------------------------------------------------------------------------
// Input
// - tfm.fmFreq: modul�cios jel frekvenci�ja
// - tfm.fsample: kiv�nt mintav�telez�si frekvencia (samplefreq)
// Output
// - tfm.fsample
// - tfm.tstep
// - DdsSamplesFreq() meghiv�sa
// (modul�lo jel frekvenci�j�nak v�ltoztat�sa ut�n)
void FmSampleFreqRefresh(void)
{
  uint32_t t;
  t = (tfm.fmFreq << 10) / tfm.fsample;
  if(t == 0)
    t = 1;
  if(t > 512)
    t = 512;
  if(t != tfm.tstep)
    tfm.resample = 0;  // l�p�sk�z v�ltoztat�s ut�n ujra kell gener�lni a t�bl�zatot
  tfm.tstep = t;
  tfm.fsample = tfm.fmFreq * DDS_SAMPLESIZE / t;
  DdsSamplesFreq(tfm.fsample);
}

//-----------------------------------------------------------------------------
void FmGen(void)
{
  osEvent   ctrlevent;
  control_t ctrlmsg;
  int16_t  e_mode = 0;  // encoder aktu�lis �zemmodja (0 = men�v�laszt�s, 1 = be�llit�s modosit�sa)
  int16_t  mselect = 0; // az �ppen kiv�lasztott men�pont sorsz�ma
  int16_t  runstop = 0; // ha megy az FM jel el��llit�sa, akkor 1
  uint32_t i;

  BSP_LCD_Clear(LCD_COLOR_BLACK);
  LcdFmGen(mselect, runstop, e_mode);

  for(i = 0; i < DDS_SAMPLESIZE; i++)
    ddsSamples[i] = 0;

  DdsSamplesBuffer(ddsSamples, DDS_SAMPLESIZE, 1, &FmCallback);
  FmSampleFreqRefresh();
  tfm.resample = 3;
  DdsSamplesStart();

  Status = STATUS_FMGEN;
  while(Status == STATUS_FMGEN)
  {
    ctrlevent = osMessageGet(controlQueueHandle, osWaitForever);
    ctrlmsg.Data = ctrlevent.value.v;

    if(ctrlmsg.Control == ENCODER_BTN_SHORTCLICK)
    { // r�vid katt
      if(e_mode == 0)
        e_mode = 1;     // Encoder rotate: settings
      else if(e_mode == 1)
        e_mode = 0;     // Encoder rotate: menu select
      LcdFmGen(mselect, runstop, e_mode);
    }
    else if(ctrlmsg.Control == ENCODER_BTN_LONGCLICK)
    { // hosszu katt
    }
    else if(ctrlmsg.Control == ENCODER_BTN_DOUBLECLICK)
    { // dupla katt
      Status = STATUS_STOP;    // kil�p�nk
    }

    else if((ctrlmsg.Control == ENCODER_ROTATE) || (ctrlmsg.Control == ENCODER_BTN_ROTATE))
    { // teker�s
      if((e_mode == 0) && (ctrlmsg.Control == ENCODER_ROTATE))
      { // men�pont v�lt�s
        mselect += ctrlmsg.Value;
        if(mselect > 3)
          mselect = 3;
        else if(mselect < 0)
          mselect = 0;
      }
      else
      { // kiv�lasztott men�pont param�ter�nek �llit�sa
        if(mselect == 0)
        { // Start/stop
          if(ctrlmsg.Value > 0)
          { // Start
            FmSampleFreqRefresh();
            tfm.resample = 0;
            runstop = 1;
          }
          else if(ctrlmsg.Value < 0)
          { // Stop
            tfm.resample = 3;
            for(i = 0; i < DDS_SAMPLESIZE; i++)
              ddsSamples[i] = 0;
            runstop = 0;
          }
        }
        else if(mselect == 1)
        { // Viv�frekvencia/raster �llit�sa
          if(ctrlmsg.Control == ENCODER_BTN_ROTATE)
          { // Jelad� gombja benyomva (raszter �llit�s)
            tfm.fgRaster += ctrlmsg.Value;
            if(tfm.fgRaster < 0)
              tfm.fgRaster = 0;
            else if(tfm.fgRaster >= RASTERNUM -1)
              tfm.fgRaster = RASTERNUM -1;
          }
          else
          { // Jelad� gombja nincs benyomva (frekvencia �llit�s)
            tfm.fgFreq_dhz = (tfm.fgFreq_dhz / Rasters[tfm.fgRaster].fRaster) * Rasters[tfm.fgRaster].fRaster;
            tfm.fgFreq_dhz += ctrlmsg.Value * Rasters[tfm.fgRaster].fRaster;
            if(tfm.fgFreq_dhz < tfm.fmDepth_dhz)
              tfm.fgFreq_dhz = tfm.fmDepth_dhz;            // a l�kettel egy�tt sem mehet 0 al�
            else if(tfm.fgFreq_dhz > (MAXFREQHZ * 10) - tfm.fmDepth_dhz)
              tfm.fgFreq_dhz = (MAXFREQHZ * 10) - tfm.fmDepth_dhz;  // a l�kettel egy�tt sem mehet MAXFREQ f�l�
          }
          if(runstop == 1)
            tfm.resample = 0;
        }
        else if(mselect == 2)
        { // Modul�lo frekvencia �llit�s
          if(ctrlmsg.Control == ENCODER_BTN_ROTATE)
          {
            tfm.fmFreq = tfm.fmFreq / 500 * 500;
            tfm.fmFreq += ctrlmsg.Value * 500;
          }
          else
            tfm.fmFreq += ctrlmsg.Value;
          if(tfm.fmFreq < MINMODFREQ)
            tfm.fmFreq = MINMODFREQ;
          else if(tfm.fmFreq > MAXMODFREQ)
            tfm.fmFreq = MAXMODFREQ;
          if(runstop == 1)
          {
            FmSampleFreqRefresh();
            tfm.resample = 0;
          }
        }
        else if(mselect == 3)
        { // Modul�cios m�lys�g
          if(ctrlmsg.Control == ENCODER_BTN_ROTATE)
          {
            tfm.fmDepth_dhz = tfm.fmDepth_dhz / 1000 * 1000;
            tfm.fmDepth_dhz += ctrlmsg.Value * 1000;
          }
          else
          {
            tfm.fmDepth_dhz = tfm.fmDepth_dhz / 10 * 10;
            tfm.fmDepth_dhz += ctrlmsg.Value * 10;
          }
          if(tfm.fmDepth_dhz < 0)
            tfm.fmDepth_dhz = 0;
          else if(tfm.fmDepth_dhz > MAXMODDEPHT)
            tfm.fmDepth_dhz = MAXMODDEPHT;
          if(tfm.fmDepth_dhz > (MAXFREQHZ * 10) - tfm.fgFreq_dhz)
            tfm.fmDepth_dhz = (MAXFREQHZ * 10) - tfm.fgFreq_dhz;  // a l�kettel egy�tt sem mehet MAXFREQ f�l�
          if(tfm.fmDepth_dhz > tfm.fgFreq_dhz)
            tfm.fmDepth_dhz = tfm.fgFreq_dhz;            // a l�kettel egy�tt sem mehet 0 al�
          if(runstop == 1)
            tfm.resample = 0;
        }
      }

      LcdFmGen(mselect, runstop, e_mode);
    }
    else if(ctrlmsg.Control == LCD_REFRESH)
    {
      printf("ddsTime:%d\r\n", (unsigned int)ddsFmTime);
      // LcdFmGen(fgFreq_dhz, fgRaster, fmFreq, fmDepth_dhz, mselect, runstop, e_mode);
    }
  }
  for(i = 0; i < DDS_SAMPLESIZE; i++)
    ddsSamples[i] = 0;

  DdsSamplesStop();
  DdsStop();
}

//=============================================================================
void LcdFmStereoColor(int16_t mselectonoff, int16_t i)
{
  if(mselectonoff)
  {
    BSP_LCD_SetTextColor(FmStereoGenMenu[i].SelectTextColor);
    BSP_LCD_SetBackColor(FmStereoGenMenu[i].SelectBackColor);
  }
  else
  {
    BSP_LCD_SetTextColor(FmStereoGenMenu[i].TextColor);
    BSP_LCD_SetBackColor(FmStereoGenMenu[i].BackColor);
  }
}

//-----------------------------------------------------------------------------
void LcdFmStereoGen(int32_t f, int32_t r, int32_t mf, int32_t md, int16_t mselect, int16_t runstop, int16_t em)
{
  uint32_t a;
  int16_t i;

  // �zemmod
  if(runstop)
    i = 1;
  else
    i = 0;
  LcdFmStereoColor(mselect == 0, i);
  BSP_LCD_DisplayStringAt(FmStereoGenMenu[i].x, FmStereoGenMenu[i].y, (uint8_t *)FmStereoGenMenu[i].Menutext, CENTER_MODE);

  // Frekvencia
  LcdFmStereoColor(mselect == 1, 2);
  sprintf((char *)&s, " %s%d ", (char *)FmStereoGenMenu[2].Menutext, (int)f);
  a = strlen((char *)s);
  s[a - 4] = s[a - 5]; s[a - 5] = '.';
  BSP_LCD_DisplayStringAt(FmStereoGenMenu[2].x, FmStereoGenMenu[2].y, (uint8_t *)s, CENTER_MODE);

  // Raster
  LcdFmStereoColor(mselect == 1, 3);
  sprintf((char *)&s, " %s%s ", FmStereoGenMenu[3].Menutext, Rasters[r].fRasterText);
  BSP_LCD_DisplayStringAt(FmStereoGenMenu[3].x, FmStereoGenMenu[3].y, (uint8_t *)s, CENTER_MODE);

  // Modul�cios frekvencia
  LcdFmStereoColor(mselect == 2, 4);
  sprintf((char *)&s, " %s%d ", FmStereoGenMenu[4].Menutext, (int)mf);
  BSP_LCD_DisplayStringAt(FmStereoGenMenu[4].x, FmStereoGenMenu[4].y, (uint8_t *)s, CENTER_MODE);

  // Modul�cios m�lys�g
  LcdFmStereoColor(mselect == 3, 5);
  sprintf((char *)&s, " %s%d ", FmStereoGenMenu[5].Menutext, (int)md);
  BSP_LCD_DisplayStringAt(FmStereoGenMenu[5].x, FmStereoGenMenu[5].y, (uint8_t *)s, CENTER_MODE);

  // Encoder
  if(em == 0)
    i = 6;
  else
    i = 7;
  LcdFmStereoColor(0, i);
  BSP_LCD_DisplayStringAt(FmStereoGenMenu[i].x, FmStereoGenMenu[i].y, (uint8_t *)FmStereoGenMenu[i].Menutext, CENTER_MODE);
}

//-----------------------------------------------------------------------------
void FmStereoCallback(uint32_t u)
{
  uint32_t i, sp, stp, sp19; // sp: modul�lo jel sinus pintere, sp19: pilot jel sinus pointere
  int32_t  si, si19;
  int32_t  vol_l, vol_r, vol_p19;  // bal/jobb/pilot csatorna hangereje (0..255)

  ddsFmTime++;

  if(tfmst.resample == 3)
    return;

  vol_l = 255 - tfmst.fmStBallance;
  if(vol_l > 255)
    vol_l = 255;
  vol_r = tfmst.fmStBallance + 255;
  if(vol_r > 255)
    vol_r = 255;

  vol_p19 = tfmst.fmPilotLevel;
  sp19 = 0;

  stp = tfmst.tstep;

  if(u == 0)
  {
    if((tfmst.resample & 1) == 0)
    {
      sp = 0;
      i = 0;
      while(i < (DDS_SAMPLESIZE >> 1))
      {
        getsine1024(si, sp);
        getsine1024(si19, sp19);
        ddsSamples[i] = FreqDHzToDds(tfmst.fgFreq_dhz + (int64_t)tfmst.fmDepth_dhz * (si * vol_l + si19 * vol_p19) / (32767 * 256));
        i++;
        sp19 += 256;
        getsine1024(si19, sp19);
        ddsSamples[i] = FreqDHzToDds(tfmst.fgFreq_dhz + (int64_t)tfmst.fmDepth_dhz * (si * vol_r + si19 * vol_p19) / (32767 * 256));
        i++;
        sp19 += 256;
        if(sp19 >= DDS_SAMPLESIZE)
          sp19 -= DDS_SAMPLESIZE;
        sp += stp;
        if(sp >= DDS_SAMPLESIZE)
          sp -= DDS_SAMPLESIZE;
      }
      tfmst.resample |= 1;
    }
  }
  else
  {
    if((tfmst.resample & 2) == 0)
    {
      sp = ((DDS_SAMPLESIZE >> 1) * tfmst.tstep) & (DDS_SAMPLESIZE - 1);
      i = DDS_SAMPLESIZE >> 1;
      while(i < DDS_SAMPLESIZE)
      {
        getsine1024(si, sp);
        getsine1024(si19, sp19);
        ddsSamples[i] = FreqDHzToDds(tfmst.fgFreq_dhz + (int64_t)tfmst.fmDepth_dhz * (si * vol_l + si19 * vol_p19) / (32767 * 256));
        i++;
        sp19 += 256;
        getsine1024(si19, sp19);
        ddsSamples[i] = FreqDHzToDds(tfmst.fgFreq_dhz + (int64_t)tfmst.fmDepth_dhz * (si * vol_r + si19 * vol_p19) / (32767 * 256));
        i++;
        sp19 += 256;
        if(sp19 >= DDS_SAMPLESIZE)
          sp19 -= DDS_SAMPLESIZE;
        sp += stp;
        if(sp >= DDS_SAMPLESIZE)
          sp -= DDS_SAMPLESIZE;
      }
      tfmst.resample |= 2;
    }
  }
}

//-----------------------------------------------------------------------------
// Input
// - tfmst.fmFreq: modul�cios jel frekvenci�ja
// - tfmst.fsample: kiv�nt mintav�telez�si frekvencia (samplefreq)
// Output
// - tfmst.fsample
// - tfmst.tstep
// - DdsSamplesFreq() meghiv�sa
// (modul�lo jel frekvenci�j�nak v�ltoztat�sa ut�n)
void FmStereoSampleFreqRefresh(void)
{
  uint32_t t;
  t = (tfmst.fmFreq << 10) / tfmst.fsample;
  if(t == 0)
    t = 1;
  if(t > 512)
    t = 512;
  if(t != tfmst.tstep)
    tfmst.resample = 0;  // l�p�sk�z v�ltoztat�s ut�n ujra kell gener�lni a t�bl�zatot
  tfmst.tstep = t;
  tfmst.fsample = tfmst.fmFreq * DDS_SAMPLESIZE / t;
  DdsSamplesFreq(tfmst.fsample);
}

//-----------------------------------------------------------------------------
void FmStereoGen(void)
{
  osEvent   ctrlevent;
  control_t ctrlmsg;
  int16_t  e_mode = 0;  // encoder aktu�lis �zemmodja (0 = men�v�laszt�s, 1 = be�llit�s modosit�sa)
  int16_t  mselect = 0; // az �ppen kiv�lasztott men�pont sorsz�ma
  int16_t  runstop = 0; // ha megy az FM jel el��llit�sa, akkor 1
  uint32_t i;

  BSP_LCD_Clear(LCD_COLOR_BLACK);
  LcdFmStereoGen(tfmst.fgFreq_dhz, tfmst.fgRaster, tfmst.fmFreq, tfmst.fmDepth_dhz, mselect, runstop, e_mode);

  for(i = 0; i < DDS_SAMPLESIZE; i++)
    ddsSamples[i] = 0;

  DdsSamplesBuffer(ddsSamples, DDS_SAMPLESIZE, 1, &FmStereoCallback);
  FmStereoSampleFreqRefresh();
  tfmst.resample = 3;
  DdsSamplesStart();

  Status = STATUS_FMGEN;
  while(Status == STATUS_FMGEN)
  {
    ctrlevent = osMessageGet(controlQueueHandle, osWaitForever);
    ctrlmsg.Data = ctrlevent.value.v;

    if(ctrlmsg.Control == ENCODER_BTN_SHORTCLICK)
    { // r�vid katt
      if(e_mode == 0)
        e_mode = 1;     // Encoder rotate: settings
      else if(e_mode == 1)
        e_mode = 0;     // Encoder rotate: menu select
      LcdFmStereoGen(tfmst.fgFreq_dhz, tfmst.fgRaster, tfmst.fmFreq, tfmst.fmDepth_dhz, mselect, runstop, e_mode);
    }
    else if(ctrlmsg.Control == ENCODER_BTN_LONGCLICK)
    { // hosszu katt
    }
    else if(ctrlmsg.Control == ENCODER_BTN_DOUBLECLICK)
    { // dupla katt
      Status = STATUS_STOP;    // kil�p�nk
    }
    else if((ctrlmsg.Control == ENCODER_ROTATE) || (ctrlmsg.Control == ENCODER_BTN_ROTATE))
    { // teker�s
      if(e_mode == 0)
      { // men�pont v�lt�s
        mselect += ctrlmsg.Value;
        if(mselect > 3)
          mselect = 3;
        else if(mselect < 0)
          mselect = 0;
      }
      else
      { // kiv�lasztott men�pont param�ter�nek �llit�sa
        if(mselect == 0)
        { // Start/stop
          if(ctrlmsg.Value > 0)
          { // Start
            FmStereoSampleFreqRefresh();
            tfmst.resample = 0;
            runstop = 1;
          }
          else if(ctrlmsg.Value < 0)
          { // Stop
            tfmst.resample = 3;
            for(i = 0; i < DDS_SAMPLESIZE; i++)
              ddsSamples[i] = 0;
            runstop = 0;
          }
        }
        else if(mselect == 1)
        { // Viv�frekvencia/raster �llit�sa
          if(ctrlmsg.Control == ENCODER_BTN_ROTATE)
          { // Jelad� gombja benyomva (raszter �llit�s)
            tfmst.fgRaster += ctrlmsg.Value;
            if(tfmst.fgRaster < 0)
              tfmst.fgRaster = 0;
            else if(tfmst.fgRaster >= RASTERNUM -1)
              tfmst.fgRaster = RASTERNUM -1;
          }
          else
          { // Jelad� gombja nincs benyomva (frekvencia �llit�s)
            tfmst.fgFreq_dhz = (tfmst.fgFreq_dhz / Rasters[tfmst.fgRaster].fRaster) * Rasters[tfmst.fgRaster].fRaster;
            tfmst.fgFreq_dhz += ctrlmsg.Value * Rasters[tfmst.fgRaster].fRaster;
            if(tfmst.fgFreq_dhz < tfmst.fmDepth_dhz)
              tfmst.fgFreq_dhz = tfmst.fmDepth_dhz;           // a l�kettel egy�tt sem mehet 0 al�
            else if(tfmst.fgFreq_dhz > (MAXFREQHZ * 10) - tfmst.fmDepth_dhz)
              tfmst.fgFreq_dhz = (MAXFREQHZ * 10) - tfmst.fmDepth_dhz; // a l�kettel egy�tt sem mehet MAXFREQ f�l�
          }
          if(runstop == 1)
            tfmst.resample = 0;
        }
        else if(mselect == 2)
        { // Modul�lo frekvencia �llit�s
          if(ctrlmsg.Control == ENCODER_BTN_ROTATE)
          {
            tfmst.fmFreq = tfmst.fmFreq / 500 * 500;
            tfmst.fmFreq += ctrlmsg.Value * 500;
          }
          else
            tfmst.fmFreq += ctrlmsg.Value;
          if(tfmst.fmFreq < MINMODFREQ)
            tfmst.fmFreq = MINMODFREQ;
          else if(tfmst.fmFreq > MAXMODFREQ)
            tfmst.fmFreq = MAXMODFREQ;
          if(runstop == 1)
          {
            FmStereoSampleFreqRefresh();
            tfmst.resample = 0;
          }
        }
        else if(mselect == 3)
        { // Modul�cios m�lys�g
          if(ctrlmsg.Control == ENCODER_BTN_ROTATE)
          {
            tfmst.fmDepth_dhz = tfmst.fmDepth_dhz / 1000 * 1000;
            tfmst.fmDepth_dhz += ctrlmsg.Value * 1000;
          }
          else
          {
            tfmst.fmDepth_dhz = tfmst.fmDepth_dhz / 10 * 10;
            tfmst.fmDepth_dhz += ctrlmsg.Value * 10;
          }
          if(tfmst.fmDepth_dhz < 0)
            tfmst.fmDepth_dhz = 0;
          else if(tfmst.fmDepth_dhz > MAXMODDEPHT)
            tfmst.fmDepth_dhz = MAXMODDEPHT;
          if(tfmst.fmDepth_dhz > (MAXFREQHZ * 10) - tfmst.fgFreq_dhz)
            tfmst.fmDepth_dhz = (MAXFREQHZ * 10) - tfmst.fgFreq_dhz; // a l�kettel egy�tt sem mehet MAXFREQ f�l�
          if(tfmst.fmDepth_dhz > tfmst.fgFreq_dhz)
            tfmst.fmDepth_dhz = tfmst.fgFreq_dhz;           // a l�kettel egy�tt sem mehet 0 al�
          if(runstop == 1)
            tfmst.resample = 0;
        }
      }

      LcdFmStereoGen(tfmst.fgFreq_dhz, tfmst.fgRaster, tfmst.fmFreq, tfmst.fmDepth_dhz, mselect, runstop, e_mode);
    }
    else if(ctrlmsg.Control == LCD_REFRESH)
    {
      printf("ddsTime:%d\r\n", (unsigned int)ddsFmTime);
      // LcdFmStereoGen(fgFreq_dhz, fgRaster, fmFreq, fmDepth_dhz, mselect, runstop, e_mode);
    }
  }
  for(i = 0; i < DDS_SAMPLESIZE; i++)
    ddsSamples[i] = 0;

  DdsSamplesStop();
  DdsStop();
}
