/*
 * sweepgen.c
 *
 *  Created on: 2019. m�rc. 19.
 *      Author: Benjami
 */

#include <stdlib.h>
#include <string.h>
#include "main.h"
#include "ddsmain.h"
#include "ddsdrv.h"
#include "control.h"
#include "stm32_adafruit_lcd.h"

#define SWEEPGENMENUSIZE    8
const MENUITEM SweepGenMenu[SWEEPGENMENUSIZE] =
{
  {0, 10, DDS_DEFCOLORS, 0, "Sweep Gen Stop"},
  {0, 10, DDS_DEFCOLORS, 0, "Speep Gen Run"},
  {0, 30, DDS_DEFCOLORS, 0, "Freq:"},
  {0, 44, DDS_DEFCOLORS, 0, "Raster:"},
  {0, 70, DDS_DEFCOLORS, 0, "Mod Freq:"},
  {0, 90, DDS_DEFCOLORS, 0, "Mod Depht:"},
  {0,110, DDS_DEFCOLORS, 0, "Encoder: menuselect"},
  {0,110, DDS_DEFCOLORS, 0, " Encoder: setting  "}
};

struct TSW
{
  int32_t sweepmode;    // 0:once lin, 1:saw lin, 2:triangle lin, 3:once log, 4:saw log, 5:triangle log
  int32_t steepness;    // sec / octave
  int32_t fgStartFreq10;// tized Hz-ben be�ll�tott frekvencia (pl. 1kHz -> 10000)
  int32_t fgStartRaster;// 0 = tized Hz, 1 = 1Hz ... 18 = 1MHz
  int32_t fgEndFreq10;  // tized Hz-ben be�ll�tott frekvencia (pl. 1kHz -> 10000)
  int32_t fgEndRaster;  // 0 = tized Hz, 1 = 1Hz ... 18 = 1MHz
}tsw = {0, 10, 10000, 9, 20000, 9};

//-----------------------------------------------------------------------------
void LcdSweepGen(uint32_t f, uint32_t r)
{
  //BSP_LCD_SetTextColor(FGenMenu[0].TextColor);
  //BSP_LCD_SetBackColor(FGenMenu[0].BackColor);
  //BSP_LCD_DisplayStringAt(MainMenu[1].x, MainMenu[1].y, (uint8_t *)MainMenu[1].Menutext, CENTER_MODE);
}

//-----------------------------------------------------------------------------
void SweepCallback(uint32_t u)
{
  if(u == 0)
  { // buffer 1.fele irhato
  }
  else
  { // buffer 2.fele irhato
  }
}

//-----------------------------------------------------------------------------
void SweepGen(void)
{
  osEvent   ctrlevent;
  control_t ctrlmsg;

  BSP_LCD_Clear(LCD_COLOR_BLACK);
  LcdSweepGen(0, 0);
  Status = STATUS_SWEEPGEN;
  DdsSamplesBuffer(ddsSamples, DDS_SAMPLESIZE, 1, NULL);
  DdsSamplesFreq(1000);
  while(Status == STATUS_SWEEPGEN)
  {
    ctrlevent = osMessageGet(controlQueueHandle, osWaitForever);
    ctrlmsg.Data = ctrlevent.value.v;

    if(ctrlmsg.Control == ENCODER_BTN_DOUBLECLICK)
    {
      Status = STATUS_STOP;
    }
  }
  DdsStop();
}

