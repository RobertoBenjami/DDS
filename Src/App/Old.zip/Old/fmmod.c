/*
 * fmmod.c
 *
 *  Created on: 2019. m�rc. 19.
 *      Author: Benjami
 *
 * FM modul�tor
 */

#include <stdlib.h>
#include <string.h>
#include "main.h"
#include "ddsmain.h"
#include "ddsdrv.h"
#include "control.h"
#include "stm32_adafruit_lcd.h"

typedef struct
{ // el�j n�lk�li stereo hangminta
  uint16_t  left;
  uint16_t  right;
}PCMU16;

typedef struct
{ // el�jeles stereo hangminta
  int16_t  left;
  int16_t  right;
}PCMI16;

union
{
  uint32_t  pcm32[DDS_SAMPLESIZE]; // mintav�telezett 32bit
  PCMU16    pcmu16[DDS_SAMPLESIZE]; // mintav�telezett stereo el�jel n�lk�l
  PCMI16    pcmi16[DDS_SAMPLESIZE]; // mintav�telezett stereo el�jeles
}pcmSamples;

//-----------------------------------------------------------------------------
void FmMod(void)
{
  //osThreadList(s);
  //printf("%s\r\n", s);
  //printf("Def:%d\r\n", (unsigned int)uxTaskGetStackHighWaterMark(defaultTaskHandle));
  //printf("Smp:%d\r\n", (unsigned int)uxTaskGetStackHighWaterMark(sampleDdsTaskHandle));
  //printf("Ctr:%d\r\n", (unsigned int)uxTaskGetStackHighWaterMark(controlTaskHandle));

  char  c;
  volatile char* p = (char *)&GPIOA->ODR;
  unsigned int   i;

  GPIOA->ODR = 0x2345;
  printf("GPIOA_ODR_32_WRITE (0x2345)\r\n");

  i = GPIOA->ODR;
  printf("GPIOA_ODR_32 = 0x%X\r\n", i);

  c = *p;
  printf("GPIOA_ODR_LO = 0x%X\r\n", c);
  c = *(p + 1);
  printf("GPIOA_ODR_HI = 0x%X\r\n", c);

  *(char *)p = 0xA5;
  printf("GPIOA_ODR_LO_WRITE (0xA5)\r\n");

  i = GPIOA->ODR;
  printf("GPIOA_ODR_32 = 0x%X\r\n", i);

  GPIOA->ODR = 0x2345;
  printf("GPIOA_ODR_32_WRITE (0x2345)\r\n");

  i = GPIOA->ODR;
  printf("GPIOA_ODR_32 = 0x%X\r\n", i);

  *(char *)(p + 1) = 0x5A;
  printf("GPIOA_ODR_HI_WRITE (0x5A)\r\n");

  i = GPIOA->ODR;
  printf("GPIOA_ODR_32 = 0x%X\r\n", i);

//  c++;
//  (char*)&(GPIOA->ODR) = c;

}
