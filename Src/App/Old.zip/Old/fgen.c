/*
 * fgen.c
 *
 *  Created on: 2019. m�rc. 15.
 *      Author: Benjami
 */

#include <stdlib.h>
#include <string.h>
#include "main.h"
#include "ddsmain.h"
#include "ddsdrv.h"
#include "control.h"
#include "stm32_adafruit_lcd.h"

#define FGENMENUSIZE    3
const MENUITEM FGenMenu[FGENMENUSIZE] =
{
  {0, 10, DDS_DEFCOLORS, 0, "Frequency generator"},
  {0, 60, DDS_DEFCOLORS, 0, "Frequency:"},
  {0, 80, DDS_DEFCOLORS, 0, "Raster:"}
};


//============================================================================
void LcdFGen(int32_t f, int32_t r)
{
  uint16_t i;

  BSP_LCD_SetTextColor(FGenMenu[0].TextColor);
  BSP_LCD_SetBackColor(FGenMenu[0].BackColor);
  BSP_LCD_DisplayStringAt(FGenMenu[0].x, FGenMenu[0].y, (uint8_t *)FGenMenu[0].Menutext, CENTER_MODE);

  BSP_LCD_SetTextColor(FGenMenu[1].ModifyTextColor);
  BSP_LCD_SetBackColor(FGenMenu[1].ModifyBackColor);
  sprintf((char *)&s, "   %s%d.   ", FGenMenu[1].Menutext, (int)f);
  i = strlen((char *)s);
  s[i - 4] = s[i - 5]; s[i - 5] = '.';
  BSP_LCD_DisplayStringAt(FGenMenu[1].x, FGenMenu[1].y, s, CENTER_MODE);

  BSP_LCD_SetTextColor(FGenMenu[2].ModifyTextColor);
  BSP_LCD_SetBackColor(FGenMenu[2].ModifyBackColor);
  sprintf((char *)&s, "   %s%s.   ", FGenMenu[2].Menutext, Rasters[r].fRasterText);
  BSP_LCD_DisplayStringAt(FGenMenu[2].x, FGenMenu[2].y, s, CENTER_MODE);
}

//-----------------------------------------------------------------------------
void FGen(void)
{
  static int32_t fgFreq_dhz = 10000; // tized Hz-ben be�ll�tott frekvencia (pl. 1kHz -> 10000)
  static int32_t fgRaster = 9;   // 0 = tized Hz, 1 = 1Hz ... 18 = 1MHz

  BSP_LCD_Clear(LCD_COLOR_BLACK);

  LcdFGen(fgFreq_dhz, fgRaster);
  DdsSetFreq(FreqDHzToDds(fgFreq_dhz));

  osEvent   ctrlevent;
  control_t ctrlmsg;

  Status = STATUS_FGEN;
  while(Status == STATUS_FGEN)
  {
    ctrlevent = osMessageGet(controlQueueHandle, osWaitForever);
    ctrlmsg.Data = ctrlevent.value.v;

    if(ctrlmsg.Control == ENCODER_BTN_DOUBLECLICK)
    {
      //printf("Btn doubleclick\r\n");
      Status = STATUS_STOP;
    }

    else if(ctrlmsg.Control == ENCODER_BTN_ROTATE)
    { // Jelad� gombja benyomva (raszter �llit�s)
      fgRaster += ctrlmsg.Value;
      if(fgRaster < 0)
        fgRaster = 0;
      else if(fgRaster >= RASTERNUM -1)
        fgRaster = RASTERNUM -1;
      LcdFGen(fgFreq_dhz, fgRaster);
    }

    else if(ctrlmsg.Control == ENCODER_ROTATE)
    { // Jelad� gombja nincs benyomva (frekvencia �llit�s)
      fgFreq_dhz = (fgFreq_dhz / Rasters[fgRaster].fRaster) * Rasters[fgRaster].fRaster;
      fgFreq_dhz += ctrlmsg.Value * Rasters[fgRaster].fRaster;
      if(fgFreq_dhz < 0)
        fgFreq_dhz = 0;
      else if(fgFreq_dhz > (MAXFREQHZ * 10))
        fgFreq_dhz = (MAXFREQHZ * 10);
      DdsSetFreq(FreqDHzToDds(fgFreq_dhz));
      LcdFGen(fgFreq_dhz, fgRaster);
    }

    else if(ctrlmsg.Control == LCD_REFRESH)
    {
      //LcdFGen(fgFreq_dhz, fgRaster);
      //printf("ddsTime:%d", (int)ddsTime);
    }
  } // while(Status == FGEN)
  DdsStop();
}

