/*
 * fgen.h
 *
 *  Created on: 2019. m�rc. 15.
 *      Author: Benjami
 */

#ifndef __FGEN_H_
#define __FGEN_H_

void    FGen(void);

#endif /* __FGEN_H_ */
